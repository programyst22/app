# APK BUILD — OKA Bau OS

## Ready path: GitHub Actions
This patch includes `.github/workflows/build-android-apk.yml`.

It creates an installable Android debug APK and uploads it as the workflow artifact:
`OKA-Bau-OS-APK`.

### Required repository secret
`EXPO_PUBLIC_BACKEND_URL`

Set it to the deployed backend base URL, for example:
`https://your-backend.example.com`

### Build
GitHub → Actions → **Build Android APK** → **Run workflow**.

After success:
Actions → latest run → Artifacts → **OKA-Bau-OS-APK**.

## Alternative: Expo EAS
`frontend/eas.json` is included.
`preview` builds an `.apk`.
`production` builds an `.aab` for Google Play.

## Notes
- The GitHub Actions APK is a debug-signed installable APK intended for immediate testing.
- Google Play publishing should use the production AAB and a proper release signing setup.
- Firebase `google-services.json` remains optional for compiling/testing but is required for real Android push delivery.
